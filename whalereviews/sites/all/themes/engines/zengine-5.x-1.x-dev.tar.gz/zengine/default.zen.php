<span style="color:red;">Zengine was instructed to override the 
$hook theme function, but no valid template file was found.</span>
